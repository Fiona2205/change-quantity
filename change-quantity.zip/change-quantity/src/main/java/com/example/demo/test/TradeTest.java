package com.example.demo.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.ChangeQuantityApplication;
import com.example.demo.bean.Trade;
import com.example.demo.controller.TradeController;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ChangeQuantityApplication.class})
public class TradeTest {
	
	@Autowired
	private TradeController tradeController;
	
	@Test
	public void testTrade() {
		List<Trade> tradeList = packageTradeList();
		
		for(Trade trade :tradeList) {
			tradeController.trade(trade);
			Map<String, String> listPosition = tradeController.listPosition();
			System.out.println("each trade" + listPosition);
		}
		
		Map<String, String> listPosition = tradeController.listPosition();
		System.out.println("final Result" + listPosition);
	}
	
	@Test
	public void testAddTrade() {
		Trade trad1 = new Trade();
		trad1.setTransactionID(1);
		trad1.setTradeID(1);
		trad1.setVersion(1);
		trad1.setSecuryCode("REL");
		trad1.setQuantity(50);
		trad1.setTradeType("INSERT");
		trad1.setBuyorSell("Buy");
		List<Trade> tradeList = new ArrayList<Trade>();
		tradeList.add(trad1);
		
		for(Trade trade :tradeList) {
			tradeController.trade(trade);
			Map<String, String> listPosition = tradeController.listPosition();
			System.out.println(listPosition);
		}
		
	}
	
	private List<Trade> packageTradeList() {
		Trade trad1 = new Trade();
		trad1.setTransactionID(1);
		trad1.setTradeID(1);
		trad1.setVersion(1);
		trad1.setSecuryCode("REL");
		trad1.setQuantity(50);
		trad1.setTradeType("INSERT");
		trad1.setBuyorSell("Buy");
		
		Trade trade2 = new Trade();
		trade2.setTransactionID(2);
		trade2.setTradeID(2);
		trade2.setVersion(1);
		trade2.setSecuryCode("ITC");
		trade2.setQuantity(40);
		trade2.setTradeType("INSERT");
		trade2.setBuyorSell("Sell");
		
		Trade trade3 = new Trade();
		trade3.setTransactionID(3);
		trade3.setTradeID(3);
		trade3.setVersion(1);
		trade3.setSecuryCode("INF");
		trade3.setQuantity(70);
		trade3.setTradeType("INSERT");
		trade3.setBuyorSell("Buy");
		
		Trade trade4 = new Trade();
		trade4.setTransactionID(4);
		trade4.setTradeID(1);
		trade4.setVersion(2);
		trade4.setSecuryCode("REL");
		trade4.setQuantity(60);
		trade4.setTradeType("UPDATE");
		trade4.setBuyorSell("Buy");
		
		Trade trade5 = new Trade();
		trade5.setTransactionID(5);
		trade5.setTradeID(2);
		trade5.setVersion(2);
		trade5.setSecuryCode("ITC");
		trade5.setQuantity(30);
		trade5.setTradeType("CANCEL");
		trade5.setBuyorSell("Buy");
		
		Trade trade6 = new Trade();
		trade6.setTransactionID(6);
		trade6.setTradeID(4);
		trade6.setVersion(1);
		trade6.setSecuryCode("INF");
		trade6.setQuantity(20);
		trade6.setTradeType("INSERT");
		trade6.setBuyorSell("Sell");
		
		List<Trade> tradeList = new ArrayList<Trade>();
		tradeList.add(trad1);
		tradeList.add(trade2);
		tradeList.add(trade3);
		tradeList.add(trade4);
		tradeList.add(trade5);
		tradeList.add(trade6);
		return tradeList;
	}
}
