package com.example.demo.bean;

public class Trade {
	
	private Integer transactionID;
	
	private Integer tradeID;
	
	private Integer version;
	
	private String securyCode;
	
	private Integer quantity;
	
	private String tradeType;
	
	private String buyorSell;

	public Integer getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(Integer transactionID) {
		this.transactionID = transactionID;
	}

	public Integer getTradeID() {
		return tradeID;
	}

	public void setTradeID(Integer tradeID) {
		this.tradeID = tradeID;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getSecuryCode() {
		return securyCode;
	}

	public void setSecuryCode(String securyCode) {
		this.securyCode = securyCode;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public String getBuyorSell() {
		return buyorSell;
	}

	public void setBuyorSell(String buyorSell) {
		this.buyorSell = buyorSell;
	}
	
	
}
