package com.example.demo.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Repository;

import com.example.demo.bean.Trade;

/**
 * 
 * @author cienet
 *
 */
@Repository
public class TradeDao {
	
	public static final List<Trade> tradeList = new ArrayList<Trade>();
	
	public static final List<Trade> allTradeList = new ArrayList<Trade>();
	
	public void insertTrade(Trade trade) {
		trade.setVersion(1);
		tradeList.add(trade);
		allTradeList.add(trade);
	}
	
	public void updateTrade(Trade trade) {
		allTradeList.add(trade);
		if(tradeList != null && tradeList.size() >0) {
			for(Trade itemTrade : tradeList) {
				if(trade.getTradeID().equals(itemTrade.getTradeID())) {
					itemTrade.setSecuryCode(trade.getSecuryCode());
					itemTrade.setQuantity(trade.getQuantity());
					itemTrade.setBuyorSell(trade.getBuyorSell());
				}
			}
		}
	}
	
	public void cancelTrade(Trade trade) {
		allTradeList.add(trade);
		if(tradeList != null && tradeList.size() >0) {
			for(Trade itemTrade : tradeList) {
				if(trade.getTradeID().equals(itemTrade.getTradeID())) {
					itemTrade.setQuantity(0);
				}
			}
		}
	}
	
	public List<Trade> listTrade() {
		return tradeList;
	}
}
