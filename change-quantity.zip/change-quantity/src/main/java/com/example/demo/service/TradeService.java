package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.bean.Position;
import com.example.demo.bean.Trade;
import com.example.demo.dao.TradeDao;

@Service
public class TradeService {
	
	@Autowired
	private TradeDao tradeDao;
	
	public void addTrade(Trade trade) {
		tradeDao.insertTrade(trade);
		
	}

	public void updateTrade(Trade trade) {
		tradeDao.updateTrade(trade);
		
	}
	
	public void cancelTrade(Trade trade) {
		tradeDao.cancelTrade(trade);
	}
	
	public List<Position> listPosition() {
		List<Trade> tradeList = tradeDao.listTrade();
		List<Position> positionList = new ArrayList<Position>();
		Position relPosition = getPositionByName(tradeList, "REL");
		Position itcPosition = getPositionByName(tradeList, "ITC");
		Position infPosition = getPositionByName(tradeList, "INF");
		positionList.add(relPosition);
		positionList.add(itcPosition);
		positionList.add(infPosition);
		return positionList;
	}

	private Position getPositionByName(List<Trade> tradeList, String positionName) {
		List<Trade> relTrade = tradeList.stream()
			.filter(trade -> positionName.equals(trade.getSecuryCode())).collect(Collectors.toList());
		Integer relQuantity = calcQuantity(relTrade);
		Position position = new Position();
		position.setName(positionName);
		position.setQuantity(formatAmount(relQuantity));
		return position;
	}
	
	private Integer calcQuantity(List<Trade> tradeList) {
		if(tradeList == null || tradeList.size() == 0) {
			return null;
		} else {
			Integer totalQuantity = 0;
			for(Trade trade : tradeList) {
				if("Buy".equals(trade.getBuyorSell())) {
					totalQuantity = totalQuantity + trade.getQuantity();
				} else {
					totalQuantity = totalQuantity - trade.getQuantity();
				}
			}
			return totalQuantity;
		}
	}
	
	private String formatAmount(Integer quantity) {
		if(quantity == null) {
			return "";
		} else if (quantity > 0) {
			return "+" + quantity;
		} else {
			return quantity.toString();
		}
	}
}
