package com.example.demo.controller;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.bean.Position;
import com.example.demo.bean.Trade;
import com.example.demo.service.TradeService;

@RestController
public class TradeController {
	
	@Autowired
	private TradeService tradeService;
	
	@RequestMapping("/trade")
	public String trade(@RequestBody Trade trade) {
		if(trade.getTradeType().equals("INSERT")) {
			return addTrade(trade);
		} else if (trade.getTradeType().equals("UPDATE")) {
			return updateTrade(trade);
		}else if (trade.getTradeType().equals("CANCEL")) {
			return cancelTrade(trade);
		}
		return "succ";
	}
	
	@RequestMapping("/addTrade")
	public String addTrade(@RequestBody Trade trade) {
		tradeService.addTrade(trade);
		return "succ";
	}
	
	@RequestMapping("/updateTrade")
	public String updateTrade(@RequestBody Trade trade) {
		tradeService.updateTrade(trade);
		return "succ";
	}
	
	@RequestMapping("/cancelTrade")
	public String cancelTrade(@RequestBody Trade trade) {
		tradeService.cancelTrade(trade);
		return "succ";
	}
	
	@RequestMapping("/listPosition")
	public Map<String, String> listPosition() {
		if(tradeService.listPosition() == null || tradeService.listPosition().size() ==0) {
			return null;
		}
		return tradeService.listPosition().stream().collect(Collectors.toMap(Position::getName, Position::getQuantity));
	
		
	}
	
}
